function [points,weights] = reference_quadrature()
% points = [1.0/6.0  1.0/6.0
%           2.0/3.0  1.0/6.0
%           1.0/6.0  2.0/3.0];
% weights = [1.0/3.0;1.0/3.0;1.0/3.0];
points = [1.0/3.0 1.0/3.0];
weights = [1.0];
end